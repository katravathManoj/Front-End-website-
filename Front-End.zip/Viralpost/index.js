$(function() {

    $('#login-form-link').click(function(e) {
		$("#login-form").delay(100).fadeIn(100);
 		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
 		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});

});
function login(e){
	var a=document.getElementById("Login");
	a.style.display="block";
	navi(e);
}
function loginclose(){
	var a=document.getElementById("Login");
	a.style.display="none";
}
function navi (e) {
	// var a= e.parentNode.getElementsByClassName("activ");
	$(".activ").removeClass('activ');
	e.className="activ";
	//a.className="";
	//a.className.replace('activ','');
}
function changeNav () {
	//var a = document.getElementById("myCarousel").scrollTop;
	// var a = document.body.scrollTop;
	// console.log(a);
	console.log($('body').scrollTop());
}